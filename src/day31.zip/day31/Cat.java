package day31;

public class Cat {


    public static void main(String[] args) {
        System.out.println("Cat");
    }

     public static void main(int args) {}

    // Can you overload the main method? Yes, but the overloading version cannot be run like the standard main method
    // Can you call the main method of one class in another class?
  // Can you override the main method? No, because static methods cannot be overridden but hidden



}
