package day31.polymorphism;

public class Student {

    String name;
    String state;


    public Student(String name, String state) {
        this.name = name;
        this.state = state;
    }


    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", state='" + state + '\'' +
                '}';
    }
}
