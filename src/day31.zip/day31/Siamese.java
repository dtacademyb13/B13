package day31;

public class Siamese extends Cat{



     public static void main(String[] args) {}



}
