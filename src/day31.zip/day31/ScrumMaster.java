package day31;

public class ScrumMaster extends Employee{

    public void getPaid(){
        System.out.println("100K");
    }
}
