package day29.overrridingRules;

import day29.Appliance;
import day29.Fridge;

public class Child extends Parent{



    public void method1(){

    }

//     public void method2(double d){
//
//     }


//      void method3(){
////
//    }


  protected void method4(){}


    public int method5(){
        return 7;
    }


    public String method8(){
        return null;
    }


    public Fridge method9(){
        return null;
    }

}
