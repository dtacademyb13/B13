package day29.overriding;

public class Super {

    String name =  "Alice";


    public void printSomething(){
        System.out.println("Hello");
    }
}
