package day29;

public class Engine {

    private String make;
    private String model;
    private int year;
    private int noOfCylinders;


    public Engine(String make, String model, int year, int noOfCylinders) {
        this.make = make;
        this.model = model;
        this.year = year;
        this.noOfCylinders = noOfCylinders;
    }
}
