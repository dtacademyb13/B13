package day29;

public class Animal {


    String color;
    double weight;



    public void eat(){
        System.out.println("Animal is Eating");
    }

    public void move(){
        System.out.println("Animal is Moving");
    }
}
