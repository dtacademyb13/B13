package day29;

public class Snake extends Animal{



    public void move(){
        System.out.println("Snake is crawling");
    }


}
