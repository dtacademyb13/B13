package day29;

public class Vehicle {

    private String make;
    private String model;
    private String color;


    public Vehicle(String make, String model, String color) {
        this.make = make;
        this.model = model;
        this.color = color;
    }
}
