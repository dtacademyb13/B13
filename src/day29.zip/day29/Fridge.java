package day29;

public class Fridge extends Appliance{

    private double size;
    private boolean hasDoubleDoors;
}
