package day29;

public class OverloadingVsOverriding {



    // Method overloading -> creating a method with the same name but different parameters



}
