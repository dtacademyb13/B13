package day32;

public class Browser {

    public void open(){
        System.out.println("Generic");
    }


    public Object close(){
        return null;
    }

}
