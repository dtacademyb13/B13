package day32;

public class GPTBrowser extends Browser{


    public void open(){
        System.out.println("Open GPTBrowser");
    }
}
