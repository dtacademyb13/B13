package day32;

public class Edge extends Browser{


    public void open(){
        System.out.println("Open Edge");
    }
}
