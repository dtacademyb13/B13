package day32;

import day30.Dog;

import java.util.Scanner;

public class Chrome extends Browser
{

    public void open(){
        System.out.println("open Chrome");
    }


    public Dog close(){
        return null;
    }
}
