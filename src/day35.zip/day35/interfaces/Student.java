package day35.interfaces;

public class Student implements Movable{

    @Override
    public void throwItem() {

    }


}
