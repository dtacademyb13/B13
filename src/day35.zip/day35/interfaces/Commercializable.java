package day35.interfaces;

public interface Commercializable {


    public abstract void makeMoney();

}
