package day35.interfaces;

public interface Operatable {

    void execute();
}
