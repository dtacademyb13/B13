package day35.interfaces;

public interface Throwable {

    void throwItem();
}
