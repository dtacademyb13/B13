package day35.abstractClasses;

public abstract class Animal {


    public Animal(){

    }

    public abstract void eat();
    public abstract void move();
    public abstract void makeSound();


}
