package day35.abstractClasses;

public abstract class Canine {

    public abstract void smell();
}
