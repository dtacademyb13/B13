package day30;

public class Cup {


}
