package day36.example;

public class Apple implements Edible{
    @Override
    public void eat() {
        System.out.println("Make an apple sauce");
    }
}
