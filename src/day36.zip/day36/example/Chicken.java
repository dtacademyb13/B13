package day36.example;

public class Chicken implements Edible{
    @Override
    public void eat() {
        System.out.println("Make a fried chicken");
    }
}
