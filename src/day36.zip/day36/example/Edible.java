package day36.example;


public interface Edible {
    /*
     implement by providing eating logic
     */
    void eat();

}
