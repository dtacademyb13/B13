package day34.shapes;

public abstract class SubClass extends MyClass{

    public abstract void concreteMethod();


    public int myAbstractMethod(){
        return 0;
    }
}
