package day34.shapes;

//public final abstract class MyClass {
public  abstract class MyClass {

    public void concreteMethod(){

    }

    public abstract int myAbstractMethod();


    // final abstract and private abstract are illegal combination of modifiers
}
